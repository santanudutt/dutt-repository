How to run the examples in Eclipse
----------------------------------------
1. Copy /examples/eclipse/dynamicreports-examples from the archive to your workspace e.g. /workspace/dynamicreports-examples
2. Copy all files from /lib and /dist folders from the archive to /workspace/dynamicreports_examples/lib/
3. Run Eclipse and import project
   To import a project, follow these steps
   - go to File - Import
   - choose Existing Projects into Workspace
   - click Next button to continue
   - click the Browse button and find the project on your hard disk
   - select the project
   - click Finish to perform the import
4. Build the project